import Calculator from './components/Calculator'
import Header from './components/Header/header'
function App() {
  return (
    <>
    <Header/>
    <Calculator />
  </>
  );
}

export default App;
