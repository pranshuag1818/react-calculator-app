import React from 'react'
import './header.css'
// const b = {
//     position:"absolute",
//     top:"0",
//     bottom:"0",
// }
// ab neeche <img style={{b}}>
// useee aise

export default function Header()
{
    return(


    <img src='/images/1.png' alt=""></img>

)}
